BUILD THE APK USING ONLY YOUR PHONE (CLOUD BUILD)

This project includes a GitHub Actions workflow that builds the APK online.
You do NOT need Android Studio or a computer. You need a GitHub account and internet.

1. Open https://github.com in Chrome and sign in / create a free account.
2. Tap +, choose New repository. Name it qurani-arabic-school. Set it Private or Public, then Create repository.
3. On the new repository page choose Add file > Upload files.
4. Upload ALL files and folders from this ZIP, including the hidden .github folder.
   If GitHub mobile upload does not show hidden .github, switch Chrome to Desktop site.
5. Commit the files to the main branch.
6. Open the Actions tab. If asked, enable workflows.
7. Choose “Build Qurani Arabic School APK” on the left and tap “Run workflow”.
   If the workflow already ran after upload, open its latest successful run instead.
8. Wait for the run to finish green. Open the run, scroll to Artifacts, and download
   qurani-arabic-school-apk. Extract the downloaded ZIP; inside is app-debug.apk.
9. Tap app-debug.apk to install. If Android asks, allow Chrome / Files to install unknown apps.

IMPORTANT:
- The APK is a debug APK for personal installation/testing, not Play Store publication.
- Keep the GitHub repository Private if you do not want the source public.
- Do not share your GitHub password or verification codes.
