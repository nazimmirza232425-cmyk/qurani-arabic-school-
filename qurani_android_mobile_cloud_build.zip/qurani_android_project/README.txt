QURANI ARABIC SCHOOL — ANDROID PROJECT SOURCE

This is an Android Studio project wrapper around the supplied Qurani Arabic School web app.
It is NOT a compiled APK. This environment does not contain the Android SDK / Android build tools,
so a genuine installable APK could not be compiled or signed here.

Build the APK:
1. Install Android Studio on a computer.
2. Open this folder (QuraniArabicSchool) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).
6. Transfer that APK to the Android phone and install it. For sharing publicly, create a signed release APK.

The app content is bundled locally in app/src/main/assets/index.html. Vocabulary, games, tests,
and saved progress work inside the WebView. Browser speech-recognition support may be limited in
an offline WebView; Arabic text-to-speech depends on installed Android voices.
