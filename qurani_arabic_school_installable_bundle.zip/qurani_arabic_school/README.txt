QURANI ARABIC SCHOOL — INSTALL GUIDE

This is a small installable web app (PWA), with 100 selected common Qur'anic Arabic vocabulary entries, Roman Urdu, simple meanings, device speech playback, a word game, speaking practice, a 10-question test, search, and saved progress.

IMPORTANT:
- The app is ready as a web-app folder, but Android installation as an app requires it to be served from an HTTPS website.
- The easiest free method is to publish this folder using GitHub Pages, Cloudflare Pages, or another static HTTPS host.
- Open the published HTTPS address in Chrome on Android > menu ⋮ > Install app / Add to Home screen.
- It will then appear on the phone like an app and can cache its files for offline use.
- Opening index.html directly from a file manager is useful for testing, but it does not provide the full PWA installation experience.
- Speech audio depends on the phone's Arabic text-to-speech voice. Microphone recognition depends on browser/device support and may need internet.
- Progress is saved in that browser on that device.

Learning note:
Translations can vary with Qur'anic context. This app is a beginner vocabulary aid, not a tafsir or a substitute for a qualified teacher. The selected list is for practice and is not presented as a verified exact frequency ranking.
